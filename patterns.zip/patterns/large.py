numbers = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
print(f"Largest number is: {max(numbers)}")