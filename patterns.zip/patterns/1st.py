name = "Alice"
age = 25
height = 5.6
is_student = True

print(name, age, height, is_student)