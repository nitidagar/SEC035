fruits = ["apple", "banana", "cherry"]
fruits.append("orange")
print(fruits)