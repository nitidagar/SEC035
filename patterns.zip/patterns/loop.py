for i in range(5):
    print(i)
count = 0
while count < 5:
    print(count)
    count += 1